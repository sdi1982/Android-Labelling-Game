_Add the issue linked to this PR_
close #

_Please choose one of the two templates and delete this message and the other template_

# Template 1 [New Feature]
## Description:
_very small explanation about what was done_

## Check list for the Code Reviewer:
* [ ] CHANGELOG
* [ ] README
* [ ] Wiki
* [ ] Version Number

# Template 2 [Bug]
## Bug
### Cause:
_small explanation_

### Reproduce
_more detail steps better_
GIVEN:
WHEN:
THEN:

### How the bug was solved:
Small explanation
