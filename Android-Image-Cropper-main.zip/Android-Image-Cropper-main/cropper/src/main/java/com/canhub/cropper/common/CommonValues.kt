package com.canhub.cropper.common

object CommonValues {
    const val authority = ".cropper.fileprovider"
    const val CROP_LIB_CACHE = "CROP_LIB_CACHE"
}
